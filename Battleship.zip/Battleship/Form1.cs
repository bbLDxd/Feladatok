﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Battleship
{
    public partial class Form1 : Form
    {
        private const int gridSize = 9; 
        private const int cellSize = 50;
        private int[,] grid = new int[gridSize, gridSize];
        private int shipsRemaining = 3;
        private int shotsFired = 0;
        private Panel panel1;
        private Panel gamePanel;


        public Form1(Panel panel1)
        {
            InitializeComponent();
            InitializeGrid();
            PlaceShips();
            this.panel1 = panel1;
            panel1.Paint += new PaintEventHandler(panel1_Paint);
            InitializeGamePanel();
        }

        private void InitializeGrid()
        {
            for (int i = 0; i < gridSize; i++)
            {
                for (int j = 0; j < gridSize; j++)
                {
                    grid[i, j] = 0;
                }
            }
        }
        private void InitializeGamePanel()
        {
            gamePanel = new Panel();
            gamePanel.Location = new Point(2000, 1000); 
            gamePanel.Size = new Size(gridSize * cellSize, gridSize * cellSize); 
            gamePanel.BackColor = Color.LightBlue; 
            gamePanel.MouseClick += GamePanel_MouseClick; 
            Controls.Add(gamePanel); 
        }

        private void GamePanel_MouseClick(object sender, MouseEventArgs e)
        {
            int x = e.X / cellSize;
            int y = e.Y / cellSize;

            
        }

        private void PlaceShips()
        {
            Random rand = new Random();
            for (int i = 0; i < shipsRemaining; i++)
            {
                int x = rand.Next(0, gridSize);
                int y = rand.Next(0, gridSize);
                if (grid[x, y] == 0)
                    grid[x, y] = 1;
                else
                    i--;
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen pen = new Pen(Color.Black);

            // Rács rajzolása
            for (int i = 0; i <= gridSize; i++)
            {
                g.DrawLine(pen, 0, i * cellSize, gridSize * cellSize, i * cellSize);
                g.DrawLine(pen, i * cellSize, 0, i * cellSize, gridSize * cellSize);
            }

            // Hajók és lövések megjelenítése
            for (int i = 0; i < gridSize; i++)
            {
                for (int j = 0; j < gridSize; j++)
                {
                    if (grid[i, j] == 1) // Hajó
                    {
                        Brush brush = new SolidBrush(Color.Blue);
                        g.FillRectangle(brush, i * cellSize, j * cellSize, cellSize, cellSize);
                    }
                    else if (grid[i, j] == 2) // Találat
                    {
                        Brush brush = new SolidBrush(Color.Red);
                        g.FillEllipse(brush, i * cellSize + cellSize / 4, j * cellSize + cellSize / 4, cellSize / 2, cellSize / 2);
                    }
                    else if (grid[i, j] == 3) // Nem talált
                    {
                        Brush brush = new SolidBrush(Color.White);
                        g.FillRectangle(brush, i * cellSize, j * cellSize, cellSize, cellSize);
                    }
                }
            }
        }

        private void panel1_MouseClick(object sender, MouseEventArgs e)
        {
            int x = e.X / cellSize;
            int y = e.Y / cellSize;

            if (x < 0 || x >= gridSize || y < 0 || y >= gridSize)
                return;

            if (grid[x, y] == 1)
            {
                grid[x, y] = 2;
                shipsRemaining--;
                MessageBox.Show("Találat!");
            }
            else if (grid[x, y] == 0)
            {
                grid[x, y] = 3;
                MessageBox.Show("Nem talált!");
            }

            shotsFired++;

            panel1.Invalidate();

            if (shipsRemaining == 0)
            {
                MessageBox.Show($"Elsüllyesztetted az összes ellenséges hajót {shotsFired} lövésből!");

            }
        }
    }
}