﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Battleship
{
    static class Program
    {
      
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            
            Panel panel1 = new Panel();

            
            Form1 form1 = new Form1(panel1);

            
            form1.Controls.Add(panel1);

        
            Application.Run(form1);
        }
    }

}