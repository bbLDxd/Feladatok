﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;

namespace szinozon2
{
    public partial class Form1 : Form
    {
        private readonly List<int> titkosKod;
        private readonly List<int> aktualisTipp;
        private const int MaxProbalkozasok = 10;
        private int megmaradtProbalkozasok;

        public Form1()
        {
            InitializeComponent();
            titkosKod = TitkosKodGeneralas();
            aktualisTipp = new List<int>();

            JatekInicializalas();
        }

        private List<int> TitkosKodGeneralas()
        {
            Random rand = new Random();
            List<int> kod = new List<int>();
            for (int i = 0; i < 4; i++)
            {
                kod.Add(rand.Next(1, 7)); 
            }
            return kod;
        }

        private void JatekInicializalas()
        {
            megmaradtProbalkozasok = MaxProbalkozasok;
            SzinGombokHozzaadasa();
            TippKuldeseGombHozzaadasa();
            TippCimkekHozzaadasa();
        }

        private void SzinGombokHozzaadasa()
        {
            const int gombMeret = 60;
            const int margok = 5;
            int xPos = margok;
            int yPos = 50;

            for (int i = 1; i <= 6; i++)
            {
                Button szinGomb = new Button();
                if (i == 1) {
                    szinGomb.Text = "Piros";

                }
                
                if (i == 2) szinGomb.Text = "Kék";
                if (i == 3) szinGomb.Text = "Zöld";
                if (i == 4) szinGomb.Text = "Sárga";
                if (i == 5) szinGomb.Text = "Narancs";
                if (i == 6) szinGomb.Text = "Lila";
                szinGomb.Tag = i;
                szinGomb.Size = new Size(gombMeret, gombMeret);
                szinGomb.Location = new Point(xPos, yPos);
                szinGomb.Click += SzinGombKattintas;
                Controls.Add(szinGomb);

                xPos += gombMeret + margok;
                if (i % 3 == 0)
                {
                    xPos = margok;
                    yPos += gombMeret + margok;
                }
            }
        }

        private void TippKuldeseGombHozzaadasa()
        {
            Button tippKuldesGomb = new Button();
            tippKuldesGomb.Text = "Tipp küldése";
            tippKuldesGomb.Size = new Size(100, 40);
            tippKuldesGomb.Location = new Point(50, 300);
            tippKuldesGomb.Click += TippKuldesGombKattintas;
            Controls.Add(tippKuldesGomb);
        }

        private void TippCimkekHozzaadasa()
        {
            const int cimkeSzelesseg = 40;
            const int cimkeMagassag = 40;
            const int margok = 10;
            int xPos = 200;
            int yPos = 50;

            for (int i = 0; i < MaxProbalkozasok; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Label tippCimke = new Label();
                    tippCimke.Name = $"tippCimke{i}{j}";
                    tippCimke.BackColor = Color.LightGray;
                    tippCimke.Size = new Size(cimkeSzelesseg, cimkeMagassag);
                    tippCimke.Location = new Point(xPos + j * (cimkeSzelesseg + margok), yPos + i * (cimkeMagassag + margok));
                    Controls.Add(tippCimke);
                }
            }
        }

        private void SzinGombKattintas(object sender, EventArgs e)
        {
            Button kattintottGomb = (Button)sender;
            int valasztottSzin = (int)kattintottGomb.Tag;
            if (aktualisTipp.Count < 4)
            {
                aktualisTipp.Add(valasztottSzin);
                TippCimkekFrissitese();
            }
        }

        private void TippCimkekFrissitese()
        {
            for (int i = 0; i < aktualisTipp.Count; i++)
            {
                Label tippCimke = Controls.Find($"tippCimke{MaxProbalkozasok - megmaradtProbalkozasok}{i}", true).FirstOrDefault() as Label;
                if (tippCimke != null)
                {
                    tippCimke.BackColor = SzinVisszaadas(aktualisTipp[i]);
                }
            }
        }

        private Color SzinVisszaadas(int szam)
        {
         
            switch (szam)
            {
                case 1: return Color.Red;
                case 2: return Color.Blue;
                case 3: return Color.Green;
                case 4: return Color.Yellow;
                case 5: return Color.Orange;
                case 6: return Color.Purple;
                default: return Color.Black;
            }
        }
        private void TippCimkekTorlese()
        {
            for (int i = 0; i < 4; i++)
            {
                Label tippCimke = Controls.Find($"tippCimke{MaxProbalkozasok - megmaradtProbalkozasok}{i}", true).FirstOrDefault() as Label;
                if (tippCimke != null)
                {
                    tippCimke.BackColor = Color.LightGray;
                }
            }
        }

        private void TippKuldesGombKattintas(object sender, EventArgs e)
        {
            if (aktualisTipp.Count == 4)
            {
                TippEllenorzese();
                aktualisTipp.Clear();
                TippCimkekTorlese(); 
            }
            else
            {
                MessageBox.Show("Kérlek válassz ki 4 színt a tipphez.");
            }
        }

        private void TippEllenorzese()
        {
            int helyesPozicio = 0;
            int helyesSzin = 0;

            for (int i = 0; i < 4; i++)
            {
                if (aktualisTipp[i] == titkosKod[i])
                {
                    helyesPozicio++;
                }
                else if (titkosKod.Contains(aktualisTipp[i]))
                {
                    helyesSzin++;
                }
            }
            VisszajelzesMegjelenitese(helyesPozicio, helyesSzin);
            FrissitVisszajelzesCimke(helyesPozicio, helyesSzin, MaxProbalkozasok - megmaradtProbalkozasok);

            HozzaadVisszajelzesCimke(helyesPozicio, helyesSzin);

            VisszajelzesMegjelenitese(helyesPozicio, helyesSzin);
            megmaradtProbalkozasok--;

            if (helyesPozicio == 4)
            {
                MessageBox.Show("Gratulálunk! Kitaláltad a kódot!");
                GombokLetiltasa();
            }
            else if (megmaradtProbalkozasok == 0)
            {
                MessageBox.Show($"Sajnáljuk, elfogytak a próbálkozásaid. A kód: {string.Join("", titkosKod)}");
                GombokLetiltasa();
            }
        }

        private void VisszajelzesMegjelenitese(int helyesPozicio, int helyesSzin)
        {

            Label visszajelzesCimke = new Label();
            visszajelzesCimke.Text = $"Helyes pozíció: {helyesPozicio}, Helyes szín: {helyesSzin}";
            visszajelzesCimke.AutoSize = true;
            visszajelzesCimke.Location = new Point(400, 70);
            Controls.Add(visszajelzesCimke);
        }
        private void FrissitVisszajelzesCimke(int helyesPozicio, int helyesSzin, int probalkozasIndex)
        {
            Label visszajelzesCimke = Controls.Find($"visszajelzesCimke{MaxProbalkozasok - megmaradtProbalkozasok + probalkozasIndex}", true).FirstOrDefault() as Label;
            if (visszajelzesCimke != null)
            {
                visszajelzesCimke.Text = $"Helyes pozíció: {helyesPozicio}, Helyes szín: {helyesSzin}";
            }
        }

        private void HozzaadVisszajelzesCimke(int helyesPozicio, int helyesSzin)
        {
            Label visszajelzesCimke = new Label();
            visszajelzesCimke.Text = $"Helyes pozíció: {helyesPozicio}, Helyes szín: {helyesSzin}";
            visszajelzesCimke.AutoSize = true;
            visszajelzesCimke.Location = new Point(400, 70 + (MaxProbalkozasok - megmaradtProbalkozasok) * 30); // Elmozgatás a helyes megjelenítés érdekében
            visszajelzesCimke.Name = $"visszajelzesCimke{MaxProbalkozasok - megmaradtProbalkozasok}";
            Controls.Add(visszajelzesCimke);
        }
        private void GombokLetiltasa()
        {
            foreach (Control control in Controls)
            {
                if (control is Button gomb && gomb.Tag != null)
                {
                    gomb.Enabled = false;
                }
            }
        }
    }
}
